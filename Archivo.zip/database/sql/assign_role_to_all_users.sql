-- Script para asignar rol ID 4 (User) a todos los usuarios
-- Fecha: 2025-08-13

-- Verificar estado inicial
SELECT 'Estado inicial:' as info;
SELECT COUNT(*) as total_usuarios FROM users;
SELECT COUNT(*) as usuarios_con_rol_antes FROM role_user;

-- Insertar todos los usuarios con rol ID 4
-- Usamos INSERT IGNORE para evitar duplicados en caso de que algún usuario ya tenga el rol
INSERT IGNORE INTO role_user (role_id, user_id, assigned_by, assigned_at, created_at, updated_at)
SELECT 
    4 as role_id,                -- Rol ID 4 = User
    u.id as user_id,              -- ID del usuario
    1 as assigned_by,             -- Asignado por usuario ID 1 (admin)
    NOW() as assigned_at,         -- Fecha de asignación
    NOW() as created_at,
    NOW() as updated_at
FROM users u
WHERE NOT EXISTS (
    -- Solo insertar si el usuario no tiene ya este rol
    SELECT 1 FROM role_user ru 
    WHERE ru.user_id = u.id AND ru.role_id = 4
);

-- Verificar resultados
SELECT 'Resultados después de la asignación:' as info;
SELECT COUNT(*) as usuarios_con_rol_despues FROM role_user WHERE role_id = 4;
SELECT COUNT(DISTINCT user_id) as total_usuarios_con_roles FROM role_user;

-- Mostrar estadísticas por rol
SELECT 
    r.id,
    r.name,
    r.display_name,
    COUNT(ru.user_id) as usuarios_asignados
FROM roles r
LEFT JOIN role_user ru ON r.id = ru.role_id
GROUP BY r.id, r.name, r.display_name
ORDER BY r.id;

-- Verificar algunos usuarios aleatorios con su rol asignado
SELECT 'Muestra de usuarios con rol asignado:' as info;
SELECT 
    u.id,
    u.name,
    u.email,
    r.name as rol_name,
    ru.assigned_at
FROM users u
INNER JOIN role_user ru ON u.id = ru.user_id
INNER JOIN roles r ON ru.role_id = r.id
WHERE ru.role_id = 4
LIMIT 10;