<?php

/**
 * Script para actualizar nombres de usuarios desde CSV
 * Actualiza la columna 'name' en la tabla users basándose en documento_identidad
 */

require_once __DIR__ . '/../../vendor/autoload.php';

// Bootstrap Laravel
$app = require_once __DIR__ . '/../../bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

// Ruta del archivo CSV
$csvFile = __DIR__ . '/../../nombres-militancia.csv';

if (!file_exists($csvFile)) {
    echo "Error: No se encuentra el archivo $csvFile\n";
    exit(1);
}

// Abrir el archivo CSV
$handle = fopen($csvFile, 'r');
if (!$handle) {
    echo "Error: No se puede abrir el archivo CSV\n";
    exit(1);
}

// Contadores
$actualizados = 0;
$no_encontrados = 0;
$errores = 0;
$linea = 0;

// Saltar la primera línea (encabezados)
fgetcsv($handle);

echo "Iniciando actualización de nombres desde CSV...\n";
echo "----------------------------------------\n";

// Procesar cada línea del CSV
while (($data = fgetcsv($handle)) !== FALSE) {
    $linea++;
    
    // Verificar que tenga las columnas necesarias
    if (count($data) < 3) {
        echo "Línea $linea: Formato incorrecto, saltando...\n";
        $errores++;
        continue;
    }
    
    $cc = trim($data[0]);
    $nombres = trim($data[1]);
    $apellidos = trim($data[2]);
    
    // Validar que CC no esté vacío
    if (empty($cc)) {
        echo "Línea $linea: CC vacío, saltando...\n";
        $errores++;
        continue;
    }
    
    // Construir el nombre completo
    $nombreCompleto = trim($nombres . ' ' . $apellidos);
    
    try {
        // Buscar y actualizar el usuario
        $updated = DB::table('users')
            ->where('documento_identidad', $cc)
            ->update(['name' => $nombreCompleto]);
        
        if ($updated > 0) {
            echo "✓ CC: $cc - Actualizado a: $nombreCompleto\n";
            $actualizados++;
        } else {
            echo "✗ CC: $cc - No encontrado en la base de datos\n";
            $no_encontrados++;
        }
        
    } catch (Exception $e) {
        echo "✗ CC: $cc - Error: " . $e->getMessage() . "\n";
        $errores++;
    }
}

fclose($handle);

// Mostrar resumen
echo "\n----------------------------------------\n";
echo "RESUMEN DE LA ACTUALIZACIÓN:\n";
echo "----------------------------------------\n";
echo "✓ Registros actualizados: $actualizados\n";
echo "⚠ Registros no encontrados: $no_encontrados\n";
echo "✗ Errores: $errores\n";
echo "Total líneas procesadas: $linea\n";
echo "----------------------------------------\n";

// Log del resultado
Log::info('Actualización de nombres desde CSV completada', [
    'actualizados' => $actualizados,
    'no_encontrados' => $no_encontrados,
    'errores' => $errores,
    'total_procesadas' => $linea
]);

echo "\nProceso completado.\n";