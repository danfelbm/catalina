-- Script de importación masiva de usuarios desde mass_users.csv
-- Fecha: 2025-08-13
-- Descripción: Importa 140k usuarios sin sobrescribir existentes

-- Crear tabla temporal para cargar el CSV
DROP TABLE IF EXISTS temp_users_import;
CREATE TABLE temp_users_import (
    estado_solicitud VARCHAR(50),
    primer_nombre VARCHAR(100),
    segundo_nombre VARCHAR(100),
    primer_apellido VARCHAR(100),
    segundo_apellido VARCHAR(100),
    tipo_documento VARCHAR(50),
    numero_documento VARCHAR(20),
    fecha_nacimiento DATE,
    nombre_usuario VARCHAR(100),
    correo_electronico VARCHAR(255),
    departamento VARCHAR(100),
    municipio VARCHAR(100),
    localidad VARCHAR(100),
    numero_celular VARCHAR(20),
    numero_celular_int VARCHAR(20),
    direccion_residencia VARCHAR(255),
    genero VARCHAR(20),
    lgbtq VARCHAR(10),
    discapacidad VARCHAR(10),
    tipo_discapacidad VARCHAR(100),
    etnia VARCHAR(50),
    desplazado VARCHAR(10),
    doc_identidad_url TEXT,
    carta_afiliacion_url TEXT,
    acepta_privacidad VARCHAR(10),
    identificacion_usuario VARCHAR(100),
    comment1 TEXT,
    comment_user1 VARCHAR(100),
    comment_date1 VARCHAR(50),
    comment2 TEXT,
    comment_user2 VARCHAR(100),
    comment_date2 VARCHAR(50),
    comment3 TEXT,
    comment_user3 VARCHAR(100),
    comment_date3 VARCHAR(50),
    comment4 TEXT,
    comment_user4 VARCHAR(100),
    comment_date4 VARCHAR(50),
    timestamp_field DATETIME,
    last_updated DATETIME,
    created_by VARCHAR(100),
    updated_by VARCHAR(100),
    entry_status VARCHAR(10),
    ip VARCHAR(50),
    id_record VARCHAR(20),
    key_field VARCHAR(20)
);

-- Cargar datos del CSV
-- IMPORTANTE: Ajustar la ruta del archivo según el sistema
LOAD DATA LOCAL INFILE '/Users/testuser/Herd/votaciones/mass_users.csv'
INTO TABLE temp_users_import
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(estado_solicitud, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido,
 tipo_documento, numero_documento, fecha_nacimiento, nombre_usuario, correo_electronico,
 departamento, municipio, localidad, numero_celular, numero_celular_int,
 direccion_residencia, genero, lgbtq, discapacidad, tipo_discapacidad,
 etnia, desplazado, doc_identidad_url, carta_afiliacion_url, acepta_privacidad,
 identificacion_usuario, comment1, comment_user1, comment_date1, comment2,
 comment_user2, comment_date2, comment3, comment_user3, comment_date3,
 comment4, comment_user4, comment_date4, timestamp_field, last_updated,
 created_by, updated_by, entry_status, ip, id_record, key_field);

-- Limpiar datos vacíos y normalizar
UPDATE temp_users_import SET
    primer_nombre = NULLIF(TRIM(primer_nombre), ''),
    segundo_nombre = NULLIF(TRIM(segundo_nombre), ''),
    primer_apellido = NULLIF(TRIM(primer_apellido), ''),
    segundo_apellido = NULLIF(TRIM(segundo_apellido), ''),
    numero_documento = NULLIF(TRIM(numero_documento), ''),
    correo_electronico = NULLIF(TRIM(correo_electronico), ''),
    departamento = NULLIF(TRIM(departamento), ''),
    municipio = NULLIF(TRIM(municipio), ''),
    localidad = NULLIF(TRIM(localidad), ''),
    numero_celular = NULLIF(TRIM(numero_celular), ''),
    direccion_residencia = NULLIF(TRIM(direccion_residencia), '');

-- Verificar cuántos registros se cargaron
SELECT COUNT(*) as total_registros_cargados FROM temp_users_import;

-- Verificar registros con documento y email válidos
SELECT COUNT(*) as registros_validos 
FROM temp_users_import 
WHERE numero_documento IS NOT NULL 
  AND correo_electronico IS NOT NULL;

-- Insertar usuarios nuevos (no duplicar por documento_identidad)
INSERT IGNORE INTO users (
    tenant_id,
    name,
    email,
    documento_identidad,
    telefono,
    direccion,
    territorio_id,
    departamento_id,
    municipio_id,
    localidad_id,
    activo,
    password,
    created_at,
    updated_at
)
SELECT DISTINCT
    1 as tenant_id, -- Todos con tenant_id = 1
    -- Combinar nombres (máximo 255 caracteres)
    LEFT(TRIM(CONCAT(
        COALESCE(t.primer_nombre, ''),
        IF(t.segundo_nombre IS NOT NULL, CONCAT(' ', t.segundo_nombre), ''),
        IF(t.primer_apellido IS NOT NULL, CONCAT(' ', t.primer_apellido), ''),
        IF(t.segundo_apellido IS NOT NULL, CONCAT(' ', t.segundo_apellido), '')
    )), 255) as name,
    LOWER(TRIM(t.correo_electronico)) as email,
    t.numero_documento as documento_identidad,
    t.numero_celular as telefono,
    LEFT(t.direccion_residencia, 255) as direccion,
    1 as territorio_id, -- Colombia por defecto
    d.id as departamento_id,
    m.id as municipio_id,
    l.id as localidad_id,
    1 as activo,
    '$2y$12$xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx' as password, -- Password temporal encriptado
    NOW() as created_at,
    NOW() as updated_at
FROM temp_users_import t
-- Join opcional con departamentos
LEFT JOIN departamentos d ON LOWER(TRIM(d.nombre)) = LOWER(TRIM(t.departamento))
-- Join opcional con municipios (debe coincidir departamento)
LEFT JOIN municipios m ON LOWER(TRIM(m.nombre)) = LOWER(TRIM(t.municipio)) 
    AND m.departamento_id = d.id
-- Join opcional con localidades (debe coincidir municipio)
LEFT JOIN localidades l ON LOWER(TRIM(l.nombre)) = LOWER(TRIM(t.localidad))
    AND l.municipio_id = m.id
WHERE 
    t.numero_documento IS NOT NULL 
    AND t.correo_electronico IS NOT NULL
    AND t.numero_documento != ''
    AND t.correo_electronico != ''
    -- No insertar si ya existe un usuario con ese documento_identidad
    AND NOT EXISTS (
        SELECT 1 FROM users u 
        WHERE u.documento_identidad = t.numero_documento
    );

-- Verificar cuántos registros se insertaron
SELECT COUNT(*) as usuarios_despues_importacion FROM users;
SELECT COUNT(*) - 1799 as nuevos_usuarios_insertados FROM users;

-- Estadísticas de la importación
SELECT 
    'Total registros en CSV' as descripcion,
    COUNT(*) as cantidad
FROM temp_users_import
UNION ALL
SELECT 
    'Registros con documento y email válidos',
    COUNT(*)
FROM temp_users_import
WHERE numero_documento IS NOT NULL 
    AND correo_electronico IS NOT NULL
    AND numero_documento != ''
    AND correo_electronico != ''
UNION ALL
SELECT 
    'Registros que ya existían (ignorados)',
    COUNT(*)
FROM temp_users_import t
WHERE EXISTS (
    SELECT 1 FROM users u 
    WHERE u.documento_identidad = t.numero_documento
)
AND t.numero_documento IS NOT NULL
UNION ALL
SELECT 
    'Nuevos usuarios insertados',
    COUNT(*) - 1799
FROM users;

-- Limpiar tabla temporal
DROP TABLE IF EXISTS temp_users_import;

-- Mensaje final
SELECT 'Importación completada exitosamente. Backup disponible en tabla users_back' as mensaje;