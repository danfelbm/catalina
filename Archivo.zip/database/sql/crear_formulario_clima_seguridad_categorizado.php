<?php
/**
 * Script para crear formulario de Encuesta de Clima de Seguridad con Categorías
 * Este script crea un formulario con todas las preguntas de la encuesta,
 * organizadas por dimensiones y con valores numéricos para análisis estadístico.
 */

require __DIR__ . '/../../vendor/autoload.php';

use Illuminate\Support\Facades\DB;

// Configuración de base de datos para conexión directa
$pdo = new PDO('mysql:host=127.0.0.1;dbname=catalina;charset=utf8mb4', 'danielb', '159753456', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);

echo "🚀 Iniciando creación del formulario de encuesta de clima de seguridad con categorías\n";

try {
    $pdo->beginTransaction();

    // Verificar si ya existe un formulario con este slug
    $stmt = $pdo->prepare("SELECT id FROM formularios WHERE slug = 'encuesta-clima-seguridad-categorizado' AND tenant_id = 1");
    $stmt->execute();
    $existingForm = $stmt->fetch();

    if ($existingForm) {
        echo "⚠️ Ya existe un formulario con slug 'encuesta-clima-seguridad-categorizado'. Eliminándolo...\n";
        $pdo->prepare("DELETE FROM formularios WHERE id = ?")->execute([$existingForm['id']]);
    }

    // Definir las categorías/dimensiones
    $categorias = [
        'dim1' => [
            'id' => 'dim1',
            'name' => 'Dim1 - Prioridad y capacidad de gestión de la seguridad y salud en el trabajo',
            'description' => 'Evalúa cómo la dirección prioriza y gestiona la seguridad y salud laboral'
        ],
        'dim2' => [
            'id' => 'dim2',
            'name' => 'Dim2 - Empoderamiento gerencial en Seguridad y Salud en el Trabajo',
            'description' => 'Mide el grado de empoderamiento y participación que la gerencia otorga a los empleados en temas de SST'
        ],
        'dim3' => [
            'id' => 'dim3',
            'name' => 'Dim3 - Administración de justicia en Seguridad y Salud en el Trabajo',
            'description' => 'Evalúa la justicia y transparencia en el manejo de accidentes e investigaciones'
        ],
        'dim4' => [
            'id' => 'dim4',
            'name' => 'Dim4 - Compromiso del trabajador en Seguridad y Salud en el Trabajo',
            'description' => 'Mide el nivel de compromiso y responsabilidad de los trabajadores con la seguridad'
        ],
        'dim5' => [
            'id' => 'dim5',
            'name' => 'Dim5 - Prioridad y no aceptación de riesgos en Seguridad y Salud en el Trabajo por parte de los trabajadores',
            'description' => 'Evalúa la actitud de los trabajadores hacia los riesgos y su aceptación de comportamientos inseguros'
        ],
        'dim6' => [
            'id' => 'dim6',
            'name' => 'Dim6 - Comunicación, aprendizaje y confianza en la capacidad en Seguridad y Salud en el trabajo entre pares',
            'description' => 'Mide la comunicación, colaboración y confianza mutua entre trabajadores en temas de seguridad'
        ],
        'dim7' => [
            'id' => 'dim7',
            'name' => 'Dim7 - Confianza de los trabajadores en la eficacia del Sistema de Gestión de Seguridad y Salud en el Trabajo',
            'description' => 'Evalúa la confianza en la efectividad de los sistemas y herramientas de gestión de SST'
        ]
    ];

    // Definir todas las preguntas con sus categorías
    $preguntasConCategorias = [
        // Preguntas iniciales (sin categoría específica)
        [
            'id' => 'compromiso_completar',
            'type' => 'radio',
            'title' => 'He leído la introducción del cuestionario y me comprometo a completarlo bajo las condiciones descritas',
            'required' => true,
            'category' => null,
            'options' => [
                ['label' => 'Si', 'value' => 1],
                ['label' => 'No', 'value' => 0]
            ]
        ],
        [
            'id' => 'edad',
            'type' => 'number',
            'title' => 'Edad',
            'description' => 'Ingrese su edad en años',
            'required' => true,
            'category' => null,
            'numberConfig' => ['min' => 18, 'max' => 100, 'step' => 1]
        ],
        [
            'id' => 'genero',
            'type' => 'radio',
            'title' => 'Usted es',
            'required' => true,
            'category' => null,
            'options' => [
                ['label' => 'Hombre', 'value' => 1],
                ['label' => 'Mujer', 'value' => 2]
            ]
        ],
        [
            'id' => 'cargo_directivo',
            'type' => 'radio',
            'title' => 'Tiene un cargo directivo, por ejemplo, gerente, jefe, supervisor, coordinador?',
            'required' => true,
            'category' => null,
            'options' => [
                ['label' => 'Si', 'value' => 1],
                ['label' => 'No', 'value' => 0]
            ]
        ],

        // Dim1 - Prioridad y capacidad de gestión de la seguridad y salud en el trabajo
        [
            'id' => 'dim1_q1',
            'type' => 'radio',
            'title' => 'La dirección anima a los empleados a trabajar de acuerdo con las reglas de seguridad y salud en el trabajo incluso cuando los tiempos de trabajo son reducidos',
            'required' => true,
            'category' => $categorias['dim1']
        ],
        [
            'id' => 'dim1_q2',
            'type' => 'radio',
            'title' => 'La dirección se asegura de que todos reciban la información necesaria sobre seguridad.',
            'required' => true,
            'category' => $categorias['dim1']
        ],
        [
            'id' => 'dim1_q3',
            'type' => 'radio',
            'title' => 'La dirección no muestra interés cuando alguien es poco cuidadoso con la seguridad',
            'required' => true,
            'category' => $categorias['dim1']
        ],
        [
            'id' => 'dim1_q4',
            'type' => 'radio',
            'title' => 'Para la dirección es más importante la seguridad que la producción',
            'required' => true,
            'category' => $categorias['dim1']
        ],
        [
            'id' => 'dim1_q5',
            'type' => 'radio',
            'title' => 'La dirección acepta que los empleados se arriesguen cuando los tiempos de trabajo son reducidos',
            'required' => true,
            'category' => $categorias['dim1']
        ],
        [
            'id' => 'dim1_q6',
            'type' => 'radio',
            'title' => 'Quienes trabajamos aquí tenemos confianza en la capacidad de la dirección para manejar la seguridad',
            'required' => true,
            'category' => $categorias['dim1']
        ],
        [
            'id' => 'dim1_q7',
            'type' => 'radio',
            'title' => 'La dirección se asegura de que todos los problemas de seguridad que se detectan durante las inspecciones sean corregidos inmediatamente',
            'required' => true,
            'category' => $categorias['dim1']
        ],
        [
            'id' => 'dim1_q8',
            'type' => 'radio',
            'title' => 'Cuando se detecta un riesgo, la dirección lo ignora y no hace nada',
            'required' => true,
            'category' => $categorias['dim1']
        ],
        [
            'id' => 'dim1_q9',
            'type' => 'radio',
            'title' => 'La dirección no tiene la capacidad de manejar la seguridad adecuadamente',
            'required' => true,
            'category' => $categorias['dim1']
        ],

        // Dim2 - Empoderamiento gerencial en Seguridad y Salud en el Trabajo
        [
            'id' => 'dim2_q1',
            'type' => 'radio',
            'title' => 'La dirección se esfuerza para diseñar rutinas de seguridad que son significativas y que realmente funcionan',
            'required' => true,
            'category' => $categorias['dim2']
        ],
        [
            'id' => 'dim2_q2',
            'type' => 'radio',
            'title' => 'La dirección se asegura de que todos los trabajadores puedan participar en la seguridad en su trabajo',
            'required' => true,
            'category' => $categorias['dim2']
        ],
        [
            'id' => 'dim2_q3',
            'type' => 'radio',
            'title' => 'La dirección anima a los empleados a participar en las decisiones que afectan su seguridad',
            'required' => true,
            'category' => $categorias['dim2']
        ],
        [
            'id' => 'dim2_q4',
            'type' => 'radio',
            'title' => 'La dirección nunca tiene en cuenta las sugerencias de los empleados sobre la seguridad',
            'required' => true,
            'category' => $categorias['dim2']
        ],
        [
            'id' => 'dim2_q5',
            'type' => 'radio',
            'title' => 'La dirección se esfuerza para que todos los empleados tengan un alto nivel de competencia respecto a la seguridad y los riesgos',
            'required' => true,
            'category' => $categorias['dim2']
        ],
        [
            'id' => 'dim2_q6',
            'type' => 'radio',
            'title' => 'La dirección nunca pide a los empleados sus opiniones antes de tomar decisiones sobre la seguridad',
            'required' => true,
            'category' => $categorias['dim2']
        ],
        [
            'id' => 'dim2_q7',
            'type' => 'radio',
            'title' => 'La dirección involucra a los empleados en la toma de decisiones sobre la seguridad',
            'required' => true,
            'category' => $categorias['dim2']
        ],

        // Dim3 - Administración de justicia en Seguridad y Salud en el Trabajo
        [
            'id' => 'dim3_q1',
            'type' => 'radio',
            'title' => 'La dirección recoge información precisa en las investigaciones sobre accidentes',
            'required' => true,
            'category' => $categorias['dim3']
        ],
        [
            'id' => 'dim3_q2',
            'type' => 'radio',
            'title' => 'El miedo a las sanciones (consecuencias negativas) de la dirección desanima a los empleados a informar sobre hechos que casi han provocado accidentes (incidentes)',
            'required' => true,
            'category' => $categorias['dim3']
        ],
        [
            'id' => 'dim3_q3',
            'type' => 'radio',
            'title' => 'La dirección escucha atentamente a todos los que han estado involucrados en un accidente',
            'required' => true,
            'category' => $categorias['dim3']
        ],
        [
            'id' => 'dim3_q4',
            'type' => 'radio',
            'title' => 'La dirección busca las causas, no a las personas culpables, cuando ocurre un accidente',
            'required' => true,
            'category' => $categorias['dim3']
        ],
        [
            'id' => 'dim3_q5',
            'type' => 'radio',
            'title' => 'La dirección siempre culpa de los accidentes a los empleados',
            'required' => true,
            'category' => $categorias['dim3']
        ],
        [
            'id' => 'dim3_q6',
            'type' => 'radio',
            'title' => 'La dirección trata a los empleados involucrados en un accidente de manera justa',
            'required' => true,
            'category' => $categorias['dim3']
        ],

        // Dim4 - Compromiso del trabajador en Seguridad y Salud en el Trabajo
        [
            'id' => 'dim4_q1',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa nos esforzamos conjuntamente por alcanzar un alto nivel de seguridad',
            'required' => true,
            'category' => $categorias['dim4']
        ],
        [
            'id' => 'dim4_q2',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa aceptamos conjuntamente la responsabilidad de asegurar que nuestro lugar de trabajo siempre esté ordenado',
            'required' => true,
            'category' => $categorias['dim4']
        ],
        [
            'id' => 'dim4_q3',
            'type' => 'radio',
            'title' => 'A quienes trabajamos en esta empresa no nos importa la seguridad de los demás',
            'required' => true,
            'category' => $categorias['dim4']
        ],
        [
            'id' => 'dim4_q4',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa evitamos combatir los riesgos detectados',
            'required' => true,
            'category' => $categorias['dim4']
        ],
        [
            'id' => 'dim4_q5',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa nos ayudamos mutuamente a trabajar seguros',
            'required' => true,
            'category' => $categorias['dim4']
        ],
        [
            'id' => 'dim4_q6',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa no aceptamos ninguna responsabilidad por la seguridad de los demás',
            'required' => true,
            'category' => $categorias['dim4']
        ],

        // Dim5 - Prioridad y no aceptación de riesgos en Seguridad y Salud en el Trabajo por parte de los trabajadores
        [
            'id' => 'dim5_q1',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa vemos los riesgos como algo que no se puede evitar',
            'required' => true,
            'category' => $categorias['dim5']
        ],
        [
            'id' => 'dim5_q2',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa consideramos los accidentes menores como una parte normal de nuestro trabajo diario',
            'required' => true,
            'category' => $categorias['dim5']
        ],
        [
            'id' => 'dim5_q3',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa aceptamos los comportamientos inseguros mientras no hayan accidentes',
            'required' => true,
            'category' => $categorias['dim5']
        ],
        [
            'id' => 'dim5_q4',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa desobedecemos las reglas de seguridad para poder terminar el trabajo a tiempo',
            'required' => true,
            'category' => $categorias['dim5']
        ],
        [
            'id' => 'dim5_q5',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa nunca aceptamos correr riesgos incluso cuando los tiempos de trabajo son reducidos',
            'required' => true,
            'category' => $categorias['dim5']
        ],
        [
            'id' => 'dim5_q6',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa consideramos que nuestro trabajo no es adecuado para los miedosos',
            'required' => true,
            'category' => $categorias['dim5']
        ],
        [
            'id' => 'dim5_q7',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa aceptamos correr riesgos en el trabajo',
            'required' => true,
            'category' => $categorias['dim5']
        ],

        // Dim6 - Comunicación, aprendizaje y confianza en la capacidad en Seguridad y Salud en el trabajo entre pares
        [
            'id' => 'dim6_q1',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa intentamos encontrar una solución si alguien nos indica un problema en la seguridad',
            'required' => true,
            'category' => $categorias['dim6']
        ],
        [
            'id' => 'dim6_q2',
            'type' => 'radio',
            'title' => 'Quienes trabajamos aquí nos sentimos seguros cuando trabajamos juntos',
            'required' => true,
            'category' => $categorias['dim6']
        ],
        [
            'id' => 'dim6_q3',
            'type' => 'radio',
            'title' => 'Quienes trabajamos aquí tenemos mucha confianza en nuestra mutua capacidad de garantizar la seguridad',
            'required' => true,
            'category' => $categorias['dim6']
        ],
        [
            'id' => 'dim6_q4',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa aprendemos de nuestras experiencias para prevenir los accidentes',
            'required' => true,
            'category' => $categorias['dim6']
        ],
        [
            'id' => 'dim6_q5',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa tomamos muy en serio las opiniones y sugerencias de los demás sobre la seguridad',
            'required' => true,
            'category' => $categorias['dim6']
        ],
        [
            'id' => 'dim6_q6',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa rara vez hablamos sobre la seguridad',
            'required' => true,
            'category' => $categorias['dim6']
        ],
        [
            'id' => 'dim6_q7',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa siempre hablamos de temas de seguridad cuando éstos surgen',
            'required' => true,
            'category' => $categorias['dim6']
        ],
        [
            'id' => 'dim6_q8',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa podemos hablar libre y abiertamente sobre la seguridad',
            'required' => true,
            'category' => $categorias['dim6']
        ],

        // Dim7 - Confianza de los trabajadores en la eficacia del Sistema de Gestión de Seguridad y Salud en el Trabajo
        [
            'id' => 'dim7_q1',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa consideramos que un buen representante de seguridad juega un papel importante en la prevención de accidentes',
            'required' => true,
            'category' => $categorias['dim7']
        ],
        [
            'id' => 'dim7_q2',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa consideramos que las inspecciones de seguridad no influyen en absoluto para generar seguridad',
            'required' => true,
            'category' => $categorias['dim7']
        ],
        [
            'id' => 'dim7_q3',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa consideramos que la formación en seguridad es buena para prevenir accidentes',
            'required' => true,
            'category' => $categorias['dim7']
        ],
        [
            'id' => 'dim7_q4',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa consideramos que la planificación anticipada de la seguridad no tiene sentido',
            'required' => true,
            'category' => $categorias['dim7']
        ],
        [
            'id' => 'dim7_q5',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa consideramos que las inspecciones de seguridad ayudan a detectar riesgos importantes',
            'required' => true,
            'category' => $categorias['dim7']
        ],
        [
            'id' => 'dim7_q6',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa consideramos que la formación en seguridad no tiene sentido',
            'required' => true,
            'category' => $categorias['dim7']
        ],
        [
            'id' => 'dim7_q7',
            'type' => 'radio',
            'title' => 'Quienes trabajamos en esta empresa consideramos que es importante que haya objetivos de seguridad claros',
            'required' => true,
            'category' => $categorias['dim7']
        ],

        // Campo final de comentarios
        [
            'id' => 'comentarios_adicionales',
            'type' => 'textarea',
            'title' => 'Si desea ampliar alguna de sus respuestas, o tiene algún comentario sobre el estudio, puede escribirlo aquí',
            'description' => 'Campo opcional para comentarios o aclaraciones adicionales',
            'required' => false,
            'category' => null,
            'placeholder' => 'Escriba aquí sus comentarios...'
        ]
    ];

    // Opciones de escala Likert para preguntas con radio
    $opcionesLikert = [
        ['label' => 'Muy de acuerdo', 'value' => 4],
        ['label' => 'De acuerdo', 'value' => 3],
        ['label' => 'En desacuerdo', 'value' => 2],
        ['label' => 'Muy en desacuerdo', 'value' => 1]
    ];

    // Procesar campos y agregar opciones a los de tipo radio (excepto los que ya las tienen)
    $configuracionCampos = [];
    foreach ($preguntasConCategorias as $pregunta) {
        // Si es campo radio y no tiene opciones específicas, usar opciones Likert
        if ($pregunta['type'] === 'radio' && !isset($pregunta['options'])) {
            $pregunta['options'] = $opcionesLikert;
        }
        
        $configuracionCampos[] = $pregunta;
    }

    // Insertar el formulario
    $stmt = $pdo->prepare("
        INSERT INTO formularios (
            tenant_id, titulo, descripcion, slug, categoria_id, 
            configuracion_campos, configuracion_general, tipo_acceso, 
            permite_visitantes, requiere_captcha, limite_por_usuario, 
            estado, activo, mensaje_confirmacion, 
            creado_por, actualizado_por, created_at, updated_at
        ) VALUES (
            1, 
            'Encuesta de Clima de Seguridad y Salud en el Trabajo (Categorizada)',
            'Esta encuesta evalúa el clima de seguridad y salud en el trabajo organizado por 7 dimensiones principales. Sus respuestas son confidenciales y nos ayudarán a mejorar las condiciones laborales mediante análisis estadístico por categorías.',
            'encuesta-clima-seguridad-categorizado',
            NULL,
            ?,
            ?,
            'publico',
            true,
            false,
            1,
            'publicado',
            true,
            'Gracias por completar la encuesta de clima de seguridad. Sus respuestas categorizadas nos permitirán realizar un análisis detallado por dimensiones para mejorar nuestro ambiente laboral.',
            1,
            1,
            NOW(),
            NOW()
        )
    ");

    $configuracionGeneral = [
        'mostrar_progreso' => true,
        'permitir_guardado_parcial' => false,
        'mostrar_resumen_final' => true,
        'mostrar_categorias' => true // Nueva opción para mostrar categorías en el frontend
    ];

    $stmt->execute([
        json_encode($configuracionCampos),
        json_encode($configuracionGeneral)
    ]);

    $formularioId = $pdo->lastInsertId();

    $pdo->commit();

    // Estadísticas
    $preguntasPorDimension = [];
    foreach ($configuracionCampos as $campo) {
        if ($campo['category']) {
            $dimId = $campo['category']['id'];
            if (!isset($preguntasPorDimension[$dimId])) {
                $preguntasPorDimension[$dimId] = 0;
            }
            $preguntasPorDimension[$dimId]++;
        }
    }

    echo "✅ Formulario categorizado creado exitosamente!\n";
    echo "📋 ID del formulario: {$formularioId}\n";
    echo "🔗 Slug: encuesta-clima-seguridad-categorizado\n";
    echo "📊 Total de preguntas: " . count($configuracionCampos) . "\n";
    echo "📁 Distribución por dimensiones:\n";
    
    foreach ($preguntasPorDimension as $dimId => $count) {
        $categoria = $categorias[$dimId];
        echo "   - {$categoria['name']}: {$count} preguntas\n";
    }
    
    echo "   - Sin categoría (demográficas): " . (count($configuracionCampos) - array_sum($preguntasPorDimension)) . " preguntas\n";
    echo "\n🎯 El formulario está listo con categorías para análisis estadístico por dimensiones.\n";
    echo "📈 Cada respuesta incluirá la categoría para generar gráficos de radar como el mostrado.\n";

} catch (Exception $e) {
    $pdo->rollBack();
    echo "❌ Error al crear el formulario: " . $e->getMessage() . "\n";
    exit(1);
}