<?php

/**
 * Script de importación masiva de usuarios desde CSV
 * Ejecutar con: php database/sql/import_mass_users_via_php.php
 */

// Configuración de base de datos
$host = 'localhost';
$dbname = 'votaciones';
$username = 'danielb';
$password = '159753456';

try {
    // Conectar a la base de datos
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Conectado a la base de datos.\n";
    
    // Verificar que el backup existe
    $stmt = $pdo->query("SELECT COUNT(*) FROM users_back");
    $backupCount = $stmt->fetchColumn();
    echo "Backup verificado: $backupCount registros en users_back\n";
    
    // Cargar departamentos, municipios y localidades en memoria para búsqueda rápida
    echo "Cargando catálogos de ubicación...\n";
    
    $departamentos = [];
    $stmt = $pdo->query("SELECT id, LOWER(TRIM(nombre)) as nombre FROM departamentos");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $departamentos[$row['nombre']] = $row['id'];
    }
    
    $municipios = [];
    $stmt = $pdo->query("SELECT id, departamento_id, LOWER(TRIM(nombre)) as nombre FROM municipios");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $key = $row['departamento_id'] . '_' . $row['nombre'];
        $municipios[$key] = $row['id'];
    }
    
    $localidades = [];
    $stmt = $pdo->query("SELECT id, municipio_id, LOWER(TRIM(nombre)) as nombre FROM localidades");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $key = $row['municipio_id'] . '_' . $row['nombre'];
        $localidades[$key] = $row['id'];
    }
    
    echo "Catálogos cargados.\n";
    
    // Cargar documentos existentes para evitar duplicados
    echo "Cargando documentos existentes...\n";
    $documentosExistentes = [];
    $stmt = $pdo->query("SELECT documento_identidad FROM users WHERE documento_identidad IS NOT NULL");
    while ($row = $stmt->fetch(PDO::FETCH_COLUMN)) {
        $documentosExistentes[$row] = true;
    }
    $totalExistentes = count($documentosExistentes);
    echo "Encontrados $totalExistentes usuarios existentes.\n";
    
    // Abrir archivo CSV
    $csvFile = '/Users/testuser/Herd/votaciones/mass_users.csv';
    if (!file_exists($csvFile)) {
        die("Error: No se encuentra el archivo $csvFile\n");
    }
    
    $handle = fopen($csvFile, 'r');
    if (!$handle) {
        die("Error: No se puede abrir el archivo CSV\n");
    }
    
    // Saltar la primera línea (encabezados)
    $headers = fgetcsv($handle);
    
    // Preparar consulta INSERT
    $insertQuery = "INSERT IGNORE INTO users (
        tenant_id, name, email, documento_identidad, telefono, direccion,
        territorio_id, departamento_id, municipio_id, localidad_id,
        activo, password, created_at, updated_at
    ) VALUES (
        :tenant_id, :name, :email, :documento_identidad, :telefono, :direccion,
        :territorio_id, :departamento_id, :municipio_id, :localidad_id,
        :activo, :password, NOW(), NOW()
    )";
    
    $insertStmt = $pdo->prepare($insertQuery);
    
    // Procesar archivo línea por línea
    echo "Procesando archivo CSV...\n";
    $totalProcesados = 0;
    $totalInsertados = 0;
    $totalIgnorados = 0;
    $totalInvalidos = 0;
    $batchSize = 1000;
    
    // Password temporal encriptado (deberá ser cambiado por el usuario)
    $defaultPassword = '$2y$12$DummyHashForTemporaryPasswordPleaseChangeItASAP.................';
    
    $pdo->beginTransaction();
    
    while (($data = fgetcsv($handle)) !== FALSE) {
        $totalProcesados++;
        
        // Mostrar progreso cada 1000 registros
        if ($totalProcesados % $batchSize == 0) {
            echo "Procesados: $totalProcesados | Insertados: $totalInsertados | Ignorados: $totalIgnorados\r";
        }
        
        // Mapear campos del CSV (índices basados en el orden de columnas)
        $primerNombre = trim($data[1] ?? '');
        $segundoNombre = trim($data[2] ?? '');
        $primerApellido = trim($data[3] ?? '');
        $segundoApellido = trim($data[4] ?? '');
        $numeroDocumento = trim($data[6] ?? '');
        $email = trim($data[9] ?? '');
        $departamento = trim($data[10] ?? '');
        $municipio = trim($data[11] ?? '');
        $localidad = trim($data[12] ?? '');
        $telefono = trim($data[13] ?? '');
        $direccion = trim($data[15] ?? '');
        
        // Validar campos requeridos
        if (empty($numeroDocumento) || empty($email)) {
            $totalInvalidos++;
            continue;
        }
        
        // Verificar si ya existe
        if (isset($documentosExistentes[$numeroDocumento])) {
            $totalIgnorados++;
            continue;
        }
        
        // Construir nombre completo
        $nombreParts = array_filter([
            $primerNombre,
            $segundoNombre,
            $primerApellido,
            $segundoApellido
        ]);
        $nombreCompleto = substr(implode(' ', $nombreParts), 0, 255);
        
        // Si no hay nombre, usar el email como nombre
        if (empty($nombreCompleto)) {
            $nombreCompleto = explode('@', $email)[0];
        }
        
        // Buscar IDs de ubicación
        $departamentoId = null;
        $municipioId = null;
        $localidadId = null;
        
        if (!empty($departamento)) {
            $depKey = strtolower(trim($departamento));
            $departamentoId = $departamentos[$depKey] ?? null;
            
            if ($departamentoId && !empty($municipio)) {
                $munKey = $departamentoId . '_' . strtolower(trim($municipio));
                $municipioId = $municipios[$munKey] ?? null;
                
                if ($municipioId && !empty($localidad)) {
                    $locKey = $municipioId . '_' . strtolower(trim($localidad));
                    $localidadId = $localidades[$locKey] ?? null;
                }
            }
        }
        
        // Ejecutar INSERT
        try {
            $insertStmt->execute([
                ':tenant_id' => 1,
                ':name' => $nombreCompleto,
                ':email' => strtolower($email),
                ':documento_identidad' => $numeroDocumento,
                ':telefono' => empty($telefono) ? null : $telefono,
                ':direccion' => empty($direccion) ? null : substr($direccion, 0, 255),
                ':territorio_id' => 1, // Colombia
                ':departamento_id' => $departamentoId,
                ':municipio_id' => $municipioId,
                ':localidad_id' => $localidadId,
                ':activo' => 1,
                ':password' => $defaultPassword
            ]);
            
            if ($insertStmt->rowCount() > 0) {
                $totalInsertados++;
                $documentosExistentes[$numeroDocumento] = true;
            } else {
                $totalIgnorados++;
            }
            
        } catch (PDOException $e) {
            // Ignorar errores de duplicados
            if ($e->getCode() == 23000) {
                $totalIgnorados++;
            } else {
                echo "\nError insertando registro: " . $e->getMessage() . "\n";
            }
        }
        
        // Commit cada 1000 registros
        if ($totalProcesados % $batchSize == 0) {
            $pdo->commit();
            $pdo->beginTransaction();
        }
    }
    
    // Commit final
    $pdo->commit();
    
    fclose($handle);
    
    // Estadísticas finales
    echo "\n\n=== RESUMEN DE IMPORTACIÓN ===\n";
    echo "Total de líneas procesadas: $totalProcesados\n";
    echo "Nuevos usuarios insertados: $totalInsertados\n";
    echo "Registros ignorados (ya existían): $totalIgnorados\n";
    echo "Registros inválidos (sin documento o email): $totalInvalidos\n";
    
    // Verificar total en base de datos
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $totalFinal = $stmt->fetchColumn();
    echo "Total de usuarios en la base de datos: $totalFinal\n";
    
    echo "\n✅ Importación completada exitosamente.\n";
    echo "Backup disponible en tabla users_back\n";
    
} catch (PDOException $e) {
    echo "Error de base de datos: " . $e->getMessage() . "\n";
    exit(1);
}