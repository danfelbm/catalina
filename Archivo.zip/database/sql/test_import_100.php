<?php

/**
 * Script de PRUEBA - Importa solo 100 registros para validación
 * Ejecutar con: php database/sql/test_import_100.php
 */

// Configuración
$host = 'localhost';
$dbname = 'votaciones';
$username = 'danielb';
$password = '159753456';
$maxRecords = 100; // Solo procesar 100 registros para prueba

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "=== MODO PRUEBA: Procesando solo $maxRecords registros ===\n\n";
    
    // Contar usuarios antes de importar
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $usuariosAntes = $stmt->fetchColumn();
    echo "Usuarios antes de importar: $usuariosAntes\n";
    
    // Cargar catálogos
    echo "Cargando catálogos...\n";
    
    $departamentos = [];
    $stmt = $pdo->query("SELECT id, LOWER(TRIM(nombre)) as nombre FROM departamentos");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $departamentos[$row['nombre']] = $row['id'];
    }
    echo "- " . count($departamentos) . " departamentos cargados\n";
    
    $municipios = [];
    $stmt = $pdo->query("SELECT id, departamento_id, LOWER(TRIM(nombre)) as nombre FROM municipios");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $key = $row['departamento_id'] . '_' . $row['nombre'];
        $municipios[$key] = $row['id'];
    }
    echo "- " . count($municipios) . " municipios cargados\n";
    
    $localidades = [];
    $stmt = $pdo->query("SELECT id, municipio_id, LOWER(TRIM(nombre)) as nombre FROM localidades");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $key = $row['municipio_id'] . '_' . $row['nombre'];
        $localidades[$key] = $row['id'];
    }
    echo "- " . count($localidades) . " localidades cargadas\n";
    
    // Cargar documentos existentes
    $documentosExistentes = [];
    $stmt = $pdo->query("SELECT documento_identidad FROM users WHERE documento_identidad IS NOT NULL");
    while ($row = $stmt->fetch(PDO::FETCH_COLUMN)) {
        $documentosExistentes[$row] = true;
    }
    echo "- " . count($documentosExistentes) . " documentos existentes\n\n";
    
    // Abrir CSV
    $csvFile = '/Users/testuser/Herd/votaciones/mass_users.csv';
    $handle = fopen($csvFile, 'r');
    if (!$handle) {
        die("Error: No se puede abrir el archivo CSV\n");
    }
    
    // Saltar encabezados
    fgetcsv($handle);
    
    // Preparar INSERT
    $insertQuery = "INSERT INTO users (
        tenant_id, name, email, documento_identidad, telefono, direccion,
        territorio_id, departamento_id, municipio_id, localidad_id,
        activo, password, created_at, updated_at
    ) VALUES (
        :tenant_id, :name, :email, :documento_identidad, :telefono, :direccion,
        :territorio_id, :departamento_id, :municipio_id, :localidad_id,
        :activo, :password, NOW(), NOW()
    )";
    
    $insertStmt = $pdo->prepare($insertQuery);
    $defaultPassword = password_hash('temporal123', PASSWORD_BCRYPT);
    
    // Procesar registros
    echo "Procesando registros...\n";
    echo str_repeat("-", 50) . "\n";
    
    $totalProcesados = 0;
    $totalInsertados = 0;
    $totalIgnorados = 0;
    $totalInvalidos = 0;
    $ejemplos = [];
    
    $pdo->beginTransaction();
    
    while (($data = fgetcsv($handle)) !== FALSE && $totalProcesados < $maxRecords) {
        $totalProcesados++;
        
        // Extraer campos
        $primerNombre = trim($data[1] ?? '');
        $segundoNombre = trim($data[2] ?? '');
        $primerApellido = trim($data[3] ?? '');
        $segundoApellido = trim($data[4] ?? '');
        $numeroDocumento = trim($data[6] ?? '');
        $email = trim($data[9] ?? '');
        $departamento = trim($data[10] ?? '');
        $municipio = trim($data[11] ?? '');
        $localidad = trim($data[12] ?? '');
        $telefono = trim($data[13] ?? '');
        $direccion = trim($data[15] ?? '');
        
        // Validar requeridos
        if (empty($numeroDocumento) || empty($email)) {
            $totalInvalidos++;
            continue;
        }
        
        // Verificar duplicado
        if (isset($documentosExistentes[$numeroDocumento])) {
            $totalIgnorados++;
            if (count($ejemplos) < 3) {
                $ejemplos[] = "Ignorado (ya existe): Doc=$numeroDocumento, Email=$email";
            }
            continue;
        }
        
        // Construir nombre
        $nombreParts = array_filter([$primerNombre, $segundoNombre, $primerApellido, $segundoApellido]);
        $nombreCompleto = substr(implode(' ', $nombreParts), 0, 255);
        if (empty($nombreCompleto)) {
            $nombreCompleto = explode('@', $email)[0];
        }
        
        // Buscar IDs de ubicación
        $departamentoId = null;
        $municipioId = null;
        $localidadId = null;
        
        if (!empty($departamento)) {
            $depKey = strtolower(trim($departamento));
            $departamentoId = $departamentos[$depKey] ?? null;
            
            if ($departamentoId && !empty($municipio)) {
                $munKey = $departamentoId . '_' . strtolower(trim($municipio));
                $municipioId = $municipios[$munKey] ?? null;
                
                if ($municipioId && !empty($localidad)) {
                    $locKey = $municipioId . '_' . strtolower(trim($localidad));
                    $localidadId = $localidades[$locKey] ?? null;
                }
            }
        }
        
        // Intentar insertar
        try {
            $insertStmt->execute([
                ':tenant_id' => 1,
                ':name' => $nombreCompleto,
                ':email' => strtolower($email),
                ':documento_identidad' => $numeroDocumento,
                ':telefono' => empty($telefono) ? null : $telefono,
                ':direccion' => empty($direccion) ? null : substr($direccion, 0, 255),
                ':territorio_id' => 1,
                ':departamento_id' => $departamentoId,
                ':municipio_id' => $municipioId,
                ':localidad_id' => $localidadId,
                ':activo' => 1,
                ':password' => $defaultPassword
            ]);
            
            $totalInsertados++;
            $documentosExistentes[$numeroDocumento] = true;
            
            if ($totalInsertados <= 3) {
                echo "✅ Insertado: $nombreCompleto (Doc: $numeroDocumento)\n";
            }
            
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { // Duplicado
                $totalIgnorados++;
            } else {
                echo "❌ Error: " . $e->getMessage() . "\n";
            }
        }
    }
    
    $pdo->commit();
    fclose($handle);
    
    // Contar usuarios después
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $usuariosDespues = $stmt->fetchColumn();
    
    // Mostrar resumen
    echo "\n" . str_repeat("=", 50) . "\n";
    echo "RESUMEN DE PRUEBA\n";
    echo str_repeat("=", 50) . "\n";
    echo "Registros procesados: $totalProcesados\n";
    echo "Nuevos insertados: $totalInsertados\n";
    echo "Ignorados (duplicados): $totalIgnorados\n";
    echo "Inválidos (sin datos): $totalInvalidos\n";
    echo "\nUsuarios antes: $usuariosAntes\n";
    echo "Usuarios después: $usuariosDespues\n";
    echo "Diferencia: " . ($usuariosDespues - $usuariosAntes) . "\n";
    
    if (count($ejemplos) > 0) {
        echo "\nEjemplos de registros ignorados:\n";
        foreach ($ejemplos as $ejemplo) {
            echo "- $ejemplo\n";
        }
    }
    
    echo "\n✅ Prueba completada exitosamente.\n";
    echo "\nSi los resultados son correctos, ejecute:\n";
    echo "php database/sql/import_mass_users_via_php.php\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    exit(1);
}