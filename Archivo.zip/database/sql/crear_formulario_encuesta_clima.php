<?php
/**
 * Script para crear formulario de Encuesta de Clima de Seguridad y Salud en el Trabajo
 * Este script crea un formulario con todas las preguntas de la encuesta,
 * configurando valores numéricos para las opciones de escalas Likert.
 */

require __DIR__ . '/../../vendor/autoload.php';

use Illuminate\Support\Facades\DB;

// Configuración de base de datos para conexión directa
$pdo = new PDO('mysql:host=127.0.0.1;dbname=catalina;charset=utf8mb4', 'danielb', '159753456', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);

echo "🚀 Iniciando creación del formulario de encuesta de clima de seguridad\n";

try {
    $pdo->beginTransaction();

    // Verificar si ya existe un formulario con este slug
    $stmt = $pdo->prepare("SELECT id FROM formularios WHERE slug = 'encuesta-clima-seguridad' AND tenant_id = 1");
    $stmt->execute();
    $existingForm = $stmt->fetch();

    if ($existingForm) {
        echo "⚠️ Ya existe un formulario con slug 'encuesta-clima-seguridad'. Eliminándolo...\n";
        $pdo->prepare("DELETE FROM formularios WHERE id = ?")->execute([$existingForm['id']]);
    }

    // Definir la configuración de campos del formulario
    $configuracionCampos = [
        // Pregunta 1: Compromiso
        [
            'id' => 'compromiso_completar',
            'type' => 'radio',
            'title' => 'He leído la introducción del cuestionario y me comprometo a completarlo bajo las condiciones descritas',
            'description' => null,
            'required' => true,
            'options' => [
                ['label' => 'Si', 'value' => 1],
                ['label' => 'No', 'value' => 0]
            ]
        ],
        
        // Pregunta 2: Edad (campo abierto, cambié tipo)
        [
            'id' => 'edad',
            'type' => 'number',
            'title' => 'Edad',
            'description' => 'Ingrese su edad en años',
            'required' => true,
            'numberConfig' => [
                'min' => 18,
                'max' => 100,
                'step' => 1
            ]
        ],
        
        // Pregunta 3: Género
        [
            'id' => 'genero',
            'type' => 'radio',
            'title' => 'Usted es',
            'description' => null,
            'required' => true,
            'options' => [
                ['label' => 'Hombre', 'value' => 1],
                ['label' => 'Mujer', 'value' => 2]
            ]
        ],
        
        // Pregunta 4: Cargo directivo
        [
            'id' => 'cargo_directivo',
            'type' => 'radio',
            'title' => 'Tiene un cargo directivo, por ejemplo, gerente, jefe, supervisor, coordinador?',
            'description' => null,
            'required' => true,
            'options' => [
                ['label' => 'Si', 'value' => 1],
                ['label' => 'No', 'value' => 0]
            ]
        ]
    ];

    // Preguntas de escala Likert (Muy de acuerdo=4, De acuerdo=3, En desacuerdo=2, Muy en desacuerdo=1)
    $preguntasLikert = [
        'La dirección anima a los empleados a trabajar de acuerdo con las reglas de seguridad y salud en el trabajo incluso cuando los tiempos de trabajo son reducidos',
        'La dirección se asegura de que todos reciban la información necesaria sobre seguridad.',
        'La dirección no muestra interés cuando alguien es poco cuidadoso con la seguridad',
        'Para la dirección es más importante la seguridad que la producción',
        'La dirección acepta que los empleados se arriesguen cuando los tiempos de trabajo son reducidos',
        'Quienes trabajamos aquí tenemos confianza en la capacidad de la dirección para manejar la seguridad',
        'La dirección se asegura de que todos los problemas de seguridad que se detectan durante las inspecciones sean corregidos inmediatamente',
        'Cuando se detecta un riesgo, la dirección lo ignora y no hace nada',
        'La dirección no tiene la capacidad de manejar la seguridad adecuadamente',
        'La dirección se esfuerza para diseñar rutinas de seguridad que son significativas y que realmente funcionan',
        'La dirección se asegura de que todos los trabajadores puedan participar en la seguridad en su trabajo',
        'La dirección anima a los empleados a participar en las decisiones que afectan su seguridad',
        'La dirección nunca tiene en cuenta las sugerencias de los empleados sobre la seguridad',
        'La dirección se esfuerza para que todos los empleados tengan un alto nivel de competencia respecto a la seguridad y los riesgos',
        'La dirección nunca pide a los empleados sus opiniones antes de tomar decisiones sobre la seguridad',
        'La dirección involucra a los empleados en la toma de decisiones sobre la seguridad',
        'La dirección recoge información precisa en las investigaciones sobre accidentes',
        'El miedo a las sanciones (consecuencias negativas) de la dirección desanima a los empleados a informar sobre hechos que casi han provocado accidentes (incidentes)',
        'La dirección escucha atentamente a todos los que han estado involucrados en un accidente',
        'La dirección busca las causas, no a las personas culpables, cuando ocurre un accidente',
        'La dirección siempre culpa de los accidentes a los empleados',
        'La dirección trata a los empleados involucrados en un accidente de manera justa',
        'Quienes trabajamos en esta empresa nos esforzamos conjuntamente por alcanzar un alto nivel de seguridad',
        'Quienes trabajamos en esta empresa aceptamos conjuntamente la responsabilidad de asegurar que nuestro lugar de trabajo siempre esté ordenado',
        'A quienes trabajamos en esta empresa no nos importa la seguridad de los demás',
        'Quienes trabajamos en esta empresa evitamos combatir los riesgos detectados',
        'Quienes trabajamos en esta empresa nos ayudamos mutuamente a trabajar seguros',
        'Quienes trabajamos en esta empresa no aceptamos ninguna responsabilidad por la seguridad de los demás',
        'Quienes trabajamos en esta empresa vemos los riesgos como algo que no se puede evitar',
        'Quienes trabajamos en esta empresa consideramos los accidentes menores como una parte normal de nuestro trabajo diario',
        'Quienes trabajamos en esta empresa aceptamos los comportamientos inseguros mientras no hayan accidentes',
        'Quienes trabajamos en esta empresa desobedecemos las reglas de seguridad para poder terminar el trabajo a tiempo',
        'Quienes trabajamos en esta empresa nunca aceptamos correr riesgos incluso cuando los tiempos de trabajo son reducidos',
        'Quienes trabajamos en esta empresa consideramos que nuestro trabajo no es adecuado para los miedosos',
        'Quienes trabajamos en esta empresa aceptamos correr riesgos en el trabajo',
        'Quienes trabajamos en esta empresa intentamos encontrar una solución si alguien nos indica un problema en la seguridad',
        'Quienes trabajamos aquí nos sentimos seguros cuando trabajamos juntos',
        'Quienes trabajamos aquí tenemos mucha confianza en nuestra mutua capacidad de garantizar la seguridad',
        'Quienes trabajamos en esta empresa aprendemos de nuestras experiencias para prevenir los accidentes',
        'Quienes trabajamos en esta empresa tomamos muy en serio las opiniones y sugerencias de los demás sobre la seguridad',
        'Quienes trabajamos en esta empresa rara vez hablamos sobre la seguridad',
        'Quienes trabajamos en esta empresa siempre hablamos de temas de seguridad cuando éstos surgen',
        'Quienes trabajamos en esta empresa podemos hablar libre y abiertamente sobre la seguridad',
        'Quienes trabajamos en esta empresa consideramos que un buen representante de seguridad juega un papel importante en la prevención de accidentes',
        'Quienes trabajamos en esta empresa consideramos que las inspecciones de seguridad no influyen en absoluto para generar seguridad',
        'Quienes trabajamos en esta empresa consideramos que la formación en seguridad es buena para prevenir accidentes',
        'Quienes trabajamos en esta empresa consideramos que la planificación anticipada de la seguridad no tiene sentido',
        'Quienes trabajamos en esta empresa consideramos que las inspecciones de seguridad ayudan a detectar riesgos importantes',
        'Quienes trabajamos en esta empresa consideramos que la formación en seguridad no tiene sentido',
        'Quienes trabajamos en esta empresa consideramos que es importante que haya objetivos de seguridad claros'
    ];

    // Agregar las preguntas Likert a la configuración
    $opcionesLikert = [
        ['label' => 'Muy de acuerdo', 'value' => 4],
        ['label' => 'De acuerdo', 'value' => 3],
        ['label' => 'En desacuerdo', 'value' => 2],
        ['label' => 'Muy en desacuerdo', 'value' => 1]
    ];

    $fieldCounter = 5; // Comenzar después de las primeras 4 preguntas
    foreach ($preguntasLikert as $pregunta) {
        $configuracionCampos[] = [
            'id' => 'likert_' . $fieldCounter,
            'type' => 'radio',
            'title' => $pregunta,
            'description' => null,
            'required' => true,
            'options' => $opcionesLikert
        ];
        $fieldCounter++;
    }

    // Pregunta final: Campo de texto libre
    $configuracionCampos[] = [
        'id' => 'comentarios_adicionales',
        'type' => 'textarea',
        'title' => 'Si desea ampliar alguna de sus respuestas, o tiene algún comentario sobre el estudio, puede escribirlo aquí',
        'description' => 'Campo opcional para comentarios o aclaraciones adicionales',
        'required' => false,
        'placeholder' => 'Escriba aquí sus comentarios...'
    ];

    // Insertar el formulario
    $stmt = $pdo->prepare("
        INSERT INTO formularios (
            tenant_id, titulo, descripcion, slug, categoria_id, 
            configuracion_campos, configuracion_general, tipo_acceso, 
            permite_visitantes, requiere_captcha, limite_por_usuario, 
            estado, activo, mensaje_confirmacion, 
            creado_por, actualizado_por, created_at, updated_at
        ) VALUES (
            1, 
            'Encuesta de Clima de Seguridad y Salud en el Trabajo',
            'Esta encuesta tiene como objetivo evaluar el clima de seguridad y salud en el trabajo en nuestra organización. Sus respuestas son confidenciales y nos ayudarán a mejorar las condiciones laborales.',
            'encuesta-clima-seguridad',
            NULL,
            ?,
            ?,
            'publico',
            true,
            false,
            1,
            'publicado',
            true,
            'Gracias por completar la encuesta de clima de seguridad. Sus respuestas son muy valiosas para mejorar las condiciones de seguridad en nuestro lugar de trabajo.',
            1,
            1,
            NOW(),
            NOW()
        )
    ");

    $configuracionGeneral = [
        'mostrar_progreso' => true,
        'permitir_guardado_parcial' => false,
        'mostrar_resumen_final' => true
    ];

    $stmt->execute([
        json_encode($configuracionCampos),
        json_encode($configuracionGeneral)
    ]);

    $formularioId = $pdo->lastInsertId();

    $pdo->commit();

    echo "✅ Formulario creado exitosamente!\n";
    echo "📋 ID del formulario: {$formularioId}\n";
    echo "🔗 Slug: encuesta-clima-seguridad\n";
    echo "📊 Preguntas creadas: " . count($configuracionCampos) . "\n";
    echo "   - 4 preguntas demográficas/introductorias\n";
    echo "   - " . count($preguntasLikert) . " preguntas de escala Likert (1-4)\n";
    echo "   - 1 campo de comentarios libre\n";
    echo "\n🎯 El formulario está listo para usar con valores numéricos configurados para análisis estadístico.\n";

} catch (Exception $e) {
    $pdo->rollBack();
    echo "❌ Error al crear el formulario: " . $e->getMessage() . "\n";
    exit(1);
}