-- ====================================
-- AGREGAR TODOS LOS USUARIOS A ASAMBLEA 1
-- ====================================

-- Verificar datos iniciales
SELECT 'DATOS INICIALES:' as info;
SELECT 
    (SELECT nombre FROM asambleas WHERE id = 1) as asamblea_nombre,
    (SELECT COUNT(*) FROM users WHERE tenant_id = 1) as usuarios_totales,
    (SELECT COUNT(*) FROM asamblea_usuario WHERE asamblea_id = 1) as usuarios_ya_en_asamblea;

-- Agregar todos los usuarios del tenant 1 a la asamblea 1
-- Solo agregará usuarios que NO estén ya en la asamblea (evita duplicados)
INSERT IGNORE INTO asamblea_usuario (
    asamblea_id,
    usuario_id, 
    tenant_id,
    tipo_participacion,
    asistio,
    created_at,
    updated_at
)
SELECT 
    1 as asamblea_id,           -- Asamblea Nacional 2024
    u.id as usuario_id,
    u.tenant_id,
    'asistente' as tipo_participacion,  -- Por defecto todos son asistentes
    0 as asistio,                       -- Por defecto no han asistido
    NOW() as created_at,
    NOW() as updated_at
FROM users u
WHERE u.tenant_id = 1               -- Solo usuarios del tenant principal
  AND u.activo = 1                  -- Solo usuarios activos
  AND NOT EXISTS (                  -- Excluir usuarios que ya están en la asamblea
      SELECT 1 
      FROM asamblea_usuario au 
      WHERE au.asamblea_id = 1 
      AND au.usuario_id = u.id
  );

-- Mostrar estadísticas finales
SELECT 'ESTADÍSTICAS FINALES:' as info;
SELECT 
    (SELECT COUNT(*) FROM asamblea_usuario WHERE asamblea_id = 1) as usuarios_en_asamblea_ahora,
    (SELECT COUNT(*) FROM users WHERE tenant_id = 1 AND activo = 1) as usuarios_activos_totales,
    CASE 
        WHEN (SELECT COUNT(*) FROM asamblea_usuario WHERE asamblea_id = 1) = 
             (SELECT COUNT(*) FROM users WHERE tenant_id = 1 AND activo = 1)
        THEN '✅ Todos los usuarios activos están en la asamblea'
        ELSE '⚠️ Algunos usuarios no se agregaron'
    END as estado;

-- Mostrar algunos usuarios agregados como muestra
SELECT 'MUESTRA DE USUARIOS EN LA ASAMBLEA:' as info;
SELECT 
    u.name,
    u.email,
    u.documento_identidad,
    d.nombre as departamento,
    m.nombre as municipio,
    au.tipo_participacion,
    au.created_at as agregado_a_asamblea
FROM asamblea_usuario au
JOIN users u ON au.usuario_id = u.id
LEFT JOIN departamentos d ON u.departamento_id = d.id  
LEFT JOIN municipios m ON u.municipio_id = m.id
WHERE au.asamblea_id = 1
  AND u.tenant_id = 1
ORDER BY au.created_at DESC
LIMIT 10;

SELECT '✅ Proceso completado exitosamente' as resultado;