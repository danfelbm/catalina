<?php
/**
 * Script para insertar respuestas del CSV al formulario ID 3
 * Lee el archivo respuestas.csv e inserta las respuestas en la base de datos
 * con datos de usuarios inventados para el sample
 */

require __DIR__ . '/../../vendor/autoload.php';

// Configuración de base de datos
$pdo = new PDO('mysql:host=127.0.0.1;dbname=catalina;charset=utf8mb4', 'danielb', '159753456', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);

echo "🚀 Iniciando inserción de respuestas desde CSV\n";

// Obtener la configuración del formulario ID 3
$stmt = $pdo->prepare("SELECT configuracion_campos FROM formularios WHERE id = 3");
$stmt->execute();
$formulario = $stmt->fetch();

if (!$formulario) {
    die("❌ Error: No se encontró el formulario con ID 3\n");
}

$configuracionCampos = json_decode($formulario['configuracion_campos'], true);
echo "✅ Formulario encontrado con " . count($configuracionCampos) . " campos\n";

// Crear mapeo de campos por posición en el CSV
$mapeoCSV = [
    0 => 'compromiso_introduccion',     // He leído la introducción
    1 => 'edad',                       // Edad
    2 => 'genero',                     // Usted es
    3 => 'cargo_directivo',            // Tiene un cargo directivo
    4 => 'likert_5',                   // Primera pregunta Likert
    5 => 'likert_6',                   // Segunda pregunta Likert
    // ... continúa hasta 51
];

// Completar el mapeo automáticamente para las preguntas Likert
for ($i = 4; $i <= 50; $i++) {
    $mapeoCSV[$i] = 'likert_' . ($i + 1);
}
$mapeoCSV[51] = 'comentarios_adicionales'; // Campo de comentarios

// Leer el archivo CSV
$csvFile = '/Users/testuser/Herd/catalina/respuestas.csv';
if (!file_exists($csvFile)) {
    die("❌ Error: No se encontró el archivo respuestas.csv\n");
}

$handle = fopen($csvFile, 'r');
if (!$handle) {
    die("❌ Error: No se pudo abrir el archivo respuestas.csv\n");
}

// Leer la primera línea (headers) y descartarla
$headers = fgetcsv($handle);
echo "✅ Headers del CSV leídos: " . count($headers) . " columnas\n";

// Mapeo de valores Likert a números
$likertMap = [
    'Muy de acuerdo' => 4,
    'De acuerdo' => 3,
    'En desacuerdo' => 2,
    'Muy en desacuerdo' => 1
];

// Nombres de prueba para usuarios
$nombresEjemplo = [
    'Ana García López',
    'Carlos Rodríguez Martín',
    'María González Pérez',
    'José Luis Fernández',
    'Laura Sánchez Torres',
    'Miguel Ángel Ruiz',
    'Carmen Jiménez Moreno',
    'Antonio López García',
    'Isabel Martín Hernández',
    'Francisco Romero Díaz',
    'Pilar Núñez Serrano',
    'Rafael Muñoz Vega',
    'Dolores Iglesias Ramos',
    'Manuel Castro Ortega',
    'Rosa María Delgado',
    'Fernando Guerrero Silva',
    'Concepción Vargas Medina',
    'Alejandro Herrera Molina',
    'Mercedes Aguilar Morales',
    'Roberto Peña Castillo'
];

// Emails de prueba
$emailsEjemplo = [
    'ana.garcia@empresa.com',
    'carlos.rodriguez@empresa.com',
    'maria.gonzalez@empresa.com',
    'jose.fernandez@empresa.com',
    'laura.sanchez@empresa.com',
    'miguel.ruiz@empresa.com',
    'carmen.jimenez@empresa.com',
    'antonio.lopez@empresa.com',
    'isabel.martin@empresa.com',
    'francisco.romero@empresa.com',
    'pilar.nunez@empresa.com',
    'rafael.munoz@empresa.com',
    'dolores.iglesias@empresa.com',
    'manuel.castro@empresa.com',
    'rosa.delgado@empresa.com',
    'fernando.guerrero@empresa.com',
    'concepcion.vargas@empresa.com',
    'alejandro.herrera@empresa.com',
    'mercedes.aguilar@empresa.com',
    'roberto.pena@empresa.com'
];

$respuestasInsertadas = 0;
$contadorUsuario = 0;

echo "📝 Comenzando inserción de respuestas...\n";

// Procesar cada línea del CSV
while (($data = fgetcsv($handle)) !== FALSE) {
    if (count($data) < 52) {
        echo "⚠️ Fila incompleta, saltando...\n";
        continue;
    }
    
    try {
        // Seleccionar nombre y email de prueba
        $nombreUsuario = $nombresEjemplo[$contadorUsuario % count($nombresEjemplo)];
        $emailUsuario = $emailsEjemplo[$contadorUsuario % count($emailsEjemplo)];
        
        // Si es un email repetido, agregar número
        if ($contadorUsuario >= count($emailsEjemplo)) {
            $numeroSufijo = floor($contadorUsuario / count($emailsEjemplo)) + 1;
            $emailUsuario = str_replace('@empresa.com', $numeroSufijo . '@empresa.com', $emailUsuario);
        }
        
        // Crear el array de respuestas
        $respuestas = [];
        
        // Mapear cada campo del CSV
        for ($i = 0; $i < count($data); $i++) {
            if (isset($mapeoCSV[$i])) {
                $campoId = $mapeoCSV[$i];
                $valor = trim($data[$i]);
                
                // Para campos Likert, convertir a valor numérico
                if (strpos($campoId, 'likert_') === 0) {
                    if (isset($likertMap[$valor])) {
                        $respuestas[$campoId] = $likertMap[$valor];
                    } else {
                        $respuestas[$campoId] = $valor; // Conservar valor original si no coincide
                    }
                } else {
                    $respuestas[$campoId] = $valor;
                }
            }
        }
        
        // Insertar la respuesta en la base de datos
        $stmt = $pdo->prepare("
            INSERT INTO formulario_respuestas 
            (formulario_id, nombre_visitante, email_visitante, respuestas, estado, codigo_confirmacion, enviado_en, created_at, updated_at)
            VALUES (?, ?, ?, ?, 'enviado', ?, NOW(), NOW(), NOW())
        ");
        
        // Generar código de confirmación único
        $codigoConfirmacion = 'CLM-' . strtoupper(bin2hex(random_bytes(6)));
        
        $stmt->execute([
            3, // formulario_id
            $nombreUsuario,
            $emailUsuario,
            json_encode($respuestas),
            $codigoConfirmacion
        ]);
        
        $respuestasInsertadas++;
        $contadorUsuario++;
        
        if ($respuestasInsertadas % 10 == 0) {
            echo "✅ Insertadas $respuestasInsertadas respuestas...\n";
        }
        
    } catch (Exception $e) {
        echo "❌ Error insertando respuesta: " . $e->getMessage() . "\n";
        continue;
    }
}

fclose($handle);

echo "\n🎉 Proceso completado!\n";
echo "📊 Respuestas insertadas: $respuestasInsertadas\n";
echo "📧 Usuarios creados: $contadorUsuario\n";

// Verificar las estadísticas
echo "\n📈 Verificando estadísticas del formulario...\n";
$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM formulario_respuestas WHERE formulario_id = 3");
$stmt->execute();
$total = $stmt->fetch()['total'];

echo "✅ Total de respuestas en la base de datos: $total\n";

// Mostrar una muestra de las respuestas insertadas
$stmt = $pdo->prepare("
    SELECT nombre_visitante, email_visitante, created_at 
    FROM formulario_respuestas 
    WHERE formulario_id = 3 
    ORDER BY created_at DESC 
    LIMIT 5
");
$stmt->execute();
$muestras = $stmt->fetchAll();

echo "\n📝 Últimas 5 respuestas insertadas:\n";
foreach ($muestras as $muestra) {
    echo "   • {$muestra['nombre_visitante']} ({$muestra['email_visitante']}) - {$muestra['created_at']}\n";
}

echo "\n✅ ¡Script completado exitosamente!\n";
echo "🔗 Puedes revisar las estadísticas en: https://catalina.test/admin/formularios/3\n";
?>